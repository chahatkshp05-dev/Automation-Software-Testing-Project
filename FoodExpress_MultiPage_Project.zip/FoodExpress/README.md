# FoodExpress – Multi-page starter

A Flask-based food ordering and delivery website prototype for an Automation Software Testing mini-project.

## Pages
- `/` – Home
- `/restaurants` – All 8 featured restaurants
- `/restaurant/<slug>` – Restaurant menu
- `/categories` – 8 food categories
- `/category/<slug>` – Restaurants in a category
- `/about` – About the project
- `/contact` – Demo contact page

## Run on Windows PowerShell
From the folder containing `app.py`:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m playwright install chromium
python app.py
```

If PowerShell blocks activation, use the virtual environment Python directly:

```powershell
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe -m playwright install chromium
.\venv\Scripts\python.exe app.py
```

Open http://127.0.0.1:5000

## Important
This is currently a multi-page frontend prototype. The menu plus buttons and contact form are demonstration UI only. Login, registration, database, cart, checkout, order APIs and automated tests will be implemented in later stages.
