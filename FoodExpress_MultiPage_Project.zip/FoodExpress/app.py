from flask import Flask, render_template, abort

app = Flask(__name__)

CATEGORIES = [
    {"name": "Pizza", "slug": "pizza", "emoji": "🍕", "description": "Cheesy classics, thin crusts and loaded toppings."},
    {"name": "Burgers", "slug": "burgers", "emoji": "🍔", "description": "Juicy burgers, crispy patties and tasty sides."},
    {"name": "Indian", "slug": "indian", "emoji": "🍛", "description": "Comforting curries, biryani, thalis and more."},
    {"name": "Chinese", "slug": "chinese", "emoji": "🥡", "description": "Noodles, fried rice, momos and Indo-Chinese favourites."},
    {"name": "Pasta", "slug": "pasta", "emoji": "🍝", "description": "Creamy, cheesy and saucy pasta bowls."},
    {"name": "Desserts", "slug": "desserts", "emoji": "🍰", "description": "Cakes, waffles, ice cream and sweet treats."},
    {"name": "Healthy", "slug": "healthy", "emoji": "🥗", "description": "Fresh salads, bowls, wraps and lighter meals."},
    {"name": "Drinks", "slug": "drinks", "emoji": "🥤", "description": "Shakes, juices, coffees and coolers."},
]

RESTAURANTS = [
    {"name": "The Pizza Studio", "slug": "pizza-studio", "cuisine": "Pizza · Italian", "rating": "4.8", "time": "25–35 min", "price": "₹250 for two", "emoji": "🍕", "categories": ["pizza", "pasta"], "description": "Hand-tossed pizzas, baked pasta and fresh garlic bread.", "items": [("Margherita Pizza", "₹199", "🍕"), ("Farmhouse Pizza", "₹279", "🍕"), ("White Sauce Pasta", "₹189", "🍝"), ("Garlic Bread", "₹99", "🥖")]},
    {"name": "Burger Barn", "slug": "burger-barn", "cuisine": "Burgers · Fast Food", "rating": "4.6", "time": "20–30 min", "price": "₹200 for two", "emoji": "🍔", "categories": ["burgers", "drinks"], "description": "Big, juicy burgers, crispy fries and chilled drinks.", "items": [("Classic Cheese Burger", "₹149", "🍔"), ("Crispy Veg Burger", "₹119", "🍔"), ("Peri Peri Fries", "₹89", "🍟"), ("Cold Coffee", "₹99", "🥤")]},
    {"name": "Spice Route Kitchen", "slug": "spice-route", "cuisine": "North Indian · Mughlai", "rating": "4.7", "time": "30–40 min", "price": "₹300 for two", "emoji": "🍛", "categories": ["indian"], "description": "Aromatic biryani, rich gravies, breads and homestyle meals.", "items": [("Paneer Butter Masala", "₹229", "🍛"), ("Veg Biryani", "₹189", "🍚"), ("Dal Makhani", "₹179", "🥘"), ("Butter Naan", "₹39", "🫓")]},
    {"name": "Wok This Way", "slug": "wok-this-way", "cuisine": "Chinese · Asian", "rating": "4.5", "time": "25–35 min", "price": "₹220 for two", "emoji": "🥡", "categories": ["chinese"], "description": "Street-style noodles, fried rice, momos and wok favourites.", "items": [("Veg Hakka Noodles", "₹159", "🍜"), ("Schezwan Fried Rice", "₹179", "🍚"), ("Veg Momos", "₹119", "🥟"), ("Chilli Potato", "₹139", "🥔")]},
    {"name": "Pasta & Co.", "slug": "pasta-co", "cuisine": "Italian · Pasta", "rating": "4.4", "time": "20–30 min", "price": "₹240 for two", "emoji": "🍝", "categories": ["pasta", "pizza"], "description": "Freshly prepared pasta with classic and modern sauces.", "items": [("Alfredo Pasta", "₹199", "🍝"), ("Arrabbiata Pasta", "₹189", "🍝"), ("Cheese Garlic Toast", "₹109", "🥪"), ("Classic Pizza Slice", "₹99", "🍕")]},
    {"name": "Sweet Tooth Corner", "slug": "sweet-tooth", "cuisine": "Desserts · Bakery", "rating": "4.9", "time": "15–25 min", "price": "₹180 for two", "emoji": "🍰", "categories": ["desserts", "drinks"], "description": "Fresh cakes, brownies, waffles and scoops of ice cream.", "items": [("Chocolate Truffle Cake", "₹129", "🍰"), ("Brownie", "₹89", "🍫"), ("Belgian Waffle", "₹149", "🧇"), ("Vanilla Scoop", "₹69", "🍨")]},
    {"name": "Green Bowl Café", "slug": "green-bowl", "cuisine": "Healthy · Salads", "rating": "4.6", "time": "20–30 min", "price": "₹260 for two", "emoji": "🥗", "categories": ["healthy", "drinks"], "description": "Colourful grain bowls, salads, wraps and fresh juices.", "items": [("Mediterranean Bowl", "₹219", "🥗"), ("Paneer Protein Wrap", "₹179", "🌯"), ("Garden Salad", "₹149", "🥬"), ("Fresh Orange Juice", "₹99", "🍊")]},
    {"name": "Sip & Shake", "slug": "sip-and-shake", "cuisine": "Beverages · Café", "rating": "4.3", "time": "15–25 min", "price": "₹150 for two", "emoji": "🥤", "categories": ["drinks", "desserts"], "description": "Thick shakes, fruit coolers, smoothies and coffee.", "items": [("Chocolate Shake", "₹129", "🥤"), ("Mango Smoothie", "₹119", "🥭"), ("Cold Coffee", "₹99", "☕"), ("Strawberry Cooler", "₹109", "🍓")]},
]

@app.route("/")
def home():
    return render_template("index.html", categories=CATEGORIES, restaurants=RESTAURANTS[:4])

@app.route("/restaurants")
def restaurants():
    return render_template("restaurants.html", restaurants=RESTAURANTS)

@app.route("/restaurant/<slug>")
def restaurant_detail(slug):
    restaurant = next((r for r in RESTAURANTS if r["slug"] == slug), None)
    if restaurant is None:
        abort(404)
    return render_template("restaurant_detail.html", restaurant=restaurant)

@app.route("/categories")
def categories():
    return render_template("categories.html", categories=CATEGORIES)

@app.route("/category/<slug>")
def category_detail(slug):
    category = next((c for c in CATEGORIES if c["slug"] == slug), None)
    if category is None:
        abort(404)
    matches = [r for r in RESTAURANTS if slug in r["categories"]]
    return render_template("category_detail.html", category=category, restaurants=matches)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

if __name__ == "__main__":
    app.run(debug=True)
